-- AlterTable
ALTER TABLE "Client" ADD COLUMN "mayor" TEXT;
ALTER TABLE "Client" ADD COLUMN "party" TEXT;
ALTER TABLE "Client" ADD COLUMN "mayorPhone" TEXT;